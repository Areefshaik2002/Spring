package com.spring;

public class Zomato implements Food{

	@Override
	public void Order() {
		System.out.println("Order placed in zomato...");
		
	}


}
