package com.spring;

public class KFC implements Food{

	@Override
	public void Order() {
		System.out.println("order placed in KFC...");
		
	}
		
}
