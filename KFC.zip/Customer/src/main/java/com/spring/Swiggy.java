package com.spring;

public class Swiggy implements Food {
	@Override
	public void Order() {
		System.out.println("Order placed at swiggy...");
	}
}
