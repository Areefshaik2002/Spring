package com.spring;

public interface Food {
	void Order();
}
